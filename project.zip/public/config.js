// Shared configuration and constants
const colors = {
    'Mock': '#FF9999',
    'ABA': '#66C2A5'
};